// Task: Change the text inside the <h1> element to "Hello, World!" when the button is clicked.
// Additionally - Log "Hello, World!" into the console

// Select the button element
const changeTextButton = document.getElementById("changeTextButton");

// Add an event listener to the button
changeTextButton.addEventListener("click", function() {
    // YOUR CODE GOES HERE
});
