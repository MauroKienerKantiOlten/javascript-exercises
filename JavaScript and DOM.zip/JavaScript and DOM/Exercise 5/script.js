// Task: Toggle visibility between the two sections by adding/removing the "hidden" class to show/hide them.
// Use `getElementById` to select both sections and the buttons, and add click event listeners to the buttons to toggle the visibility.

// YOUR CODE GOES HERE: Use `getElementById` to select sections and buttons
// Add EventLIsteners to display Sections of hide Sections