// Task: Use `getElementById` to select the image. 
// Add event listeners for "mouseenter" to hide the image and "mouseleave" to show it again.

// YOUR CODE GOES HERE: Use `getElementById` to select the image

// Add EventLIsteners on the ImageElement
// Hint: Search on the interenet if you can find the needed EventListener