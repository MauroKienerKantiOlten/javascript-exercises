// Exercise 1: Change Text Content of the Element with current Text "Original Text"
function changeText() {
    // YOUR CODE GOES HERE
}

// Exercise 2: Add Two Numbers stored in the num1 and num2 Elements of the Document
function addNumbers() {
    // YOUR CODE GOES HERE
}

// Exercise 3: Display Message "Hello, JavaScript!" on Click
function displayMessage() {
    // YOUR CODE GOES HERE
}

// Exercise 4: Calculate Square of a Number
function calculateSquare() {
    // YOUR CODE GOES HERE
    // Calculate the square of the Number stored in Element with ID numberInput
}