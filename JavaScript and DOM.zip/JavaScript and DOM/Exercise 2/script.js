// Task: Toggle the visibility of the paragraph when the button is clicked.

// Select the button and paragraph elements
// YOUR CODE GOES HERE: Use `getElementById` to select the button and paragraph elements

// Add an event listener to the button
toggleButton.addEventListener("click", function() {
    // YOUR CODE GOES HERE
});
